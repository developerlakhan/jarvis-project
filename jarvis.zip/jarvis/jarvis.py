import pyttsx3
import speech_recognition as sr
import datetime
import webbrowser
import pyautogui
import wikipedia
import os
import time
import pywhatkit

# Text to Speech Engine
engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)  # Female voice

def speak(audio):
    print("Jarvis:", audio)
    engine.say(audio)
    engine.runAndWait()

# Wish the user
def wish():
    hour = int(datetime.datetime.now().hour)
    if 0 <= hour < 12:
        speak("Good Morning , I am Jarvis. May I help you?")
    elif 12 <= hour < 18:
        speak("Good Afternoon, I am Jarvis. May I help you?")
    else:
        speak("Good Evening, I am Jarvis. May I help you?")

# Take voice command
def takeCommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)
    try:
        print("Recognizing...")
        query = r.recognize_google(audio, language='en-in')
        print(f"You said: {query}")
    except Exception:
        speak("Sorry, I didn't catch that. Please say it again.")
        return "None"
    return query.lower()

# Wikipedia search
def search_wikipedia(query):
    try:
        speak("Searching Wikipedia...")
        query = query.replace("who is", "").replace("what is", "").replace("tell me about", "")
        result = wikipedia.summary(query, sentences=2)
        speak("According to Wikipedia...")
        speak(result)
    except Exception:
        speak("Sorry, I couldn't find anything on Wikipedia.")

# Open Chrome
def open_chrome():
    chrome_path = "Your Chrome path"
    if os.path.exists(chrome_path):
        os.startfile(chrome_path)
        speak("Opening Chrome")
    else:
        speak("Chrome path not found.")

# Close Chrome
def close_chrome():
    os.system("taskkill /f /im chrome.exe")
    speak("Chrome is closed")

# Open YouTube
def open_youtube():
    speak("Opening YouTube")
    webbrowser.open("Your Youtube Link")

# Close YouTube
def close_youtube():
    os.system("taskkill /f /im chrome.exe")
    speak("YouTube is closed")

# Play song on YouTube
def play_song(song_name):
    speak(f"Playing {song_name} on YouTube")
    pywhatkit.playonyt(song_name)

# Change song (open new tab)
def change_song():
    pyautogui.hotkey('ctrl', 't')  # New tab
    time.sleep(1)
    pyautogui.typewrite("youtube Link")
    pyautogui.press('enter')
    time.sleep(2)
    speak("Changed the song")

# Volume controls
def volume_up(level=10):
    for _ in range(level):
        pyautogui.press("volumeup")
    speak(f"Volume increased")

def volume_down(level=10):
    for _ in range(level):
        pyautogui.press("volumedown")
    speak(f"Volume decreased")

# --------------------- Main Program ---------------------

if __name__ == "__main__":
    wish()
    while True:
        query = takeCommand()

        if query == "none":
            continue

        elif 'date' in query:
            date = datetime.datetime.now().strftime("%d %B %Y")
            speak(f"Today's date is {date}")

        elif 'time' in query:
            time_now = datetime.datetime.now().strftime("%I:%M %p")
            speak(f"The current time is {time_now}")

        elif 'open chrome' in query:
            open_chrome()

        elif 'close chrome' in query:
            close_chrome()

        elif 'what is date' in query:
          date = datetime.datetime.now().strftime("%d %B %Y")
          speak(f"Today's date is {date}")

        elif 'what is time' in query:
         time_now = datetime.datetime.now().strftime("%I:%M %p")
         speak(f"The current time is {time_now}")
            

        elif 'open youtube' in query:
            open_youtube()

        elif 'close youtube' in query:
            close_youtube()

        elif 'play song' in query:
            speak("Which song should I play?")
            song = takeCommand()
            if song != "none":
                play_song(song)

        elif 'change song' in query:
            change_song()

        elif 'volume up' in query:
            volume_up()

        elif 'volume down' in query:
            volume_down()

        elif 'who is' in query or 'what is' in query or 'tell me about' in query:
            search_wikipedia(query)

        elif 'exit' in query or 'stop' in query:
            speak("Jarvis going offline. Goodbye Your Name.")
            break

        else:
            speak("Sorry, I didn't understand that.")
